const page_in = document.getElementById("page_loader");
const drpd_c = document.getElementById("drpd-content");


function update_drpd() {
    if (drpd_c.style.display == "none") {
        drpd_c.style.setProperty('display', 'block');

    } else {
        drpd_c.style.setProperty('display', 'none');
    }
}

function change_page(page) {
    page_in.src = page
}