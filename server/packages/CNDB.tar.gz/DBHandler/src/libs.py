from ._libs.EZHost import *

from sys import argv

from dataclasses import dataclass, replace